﻿namespace P02_WebApr2023_Assg1_Team6.Models
{
	public class Quote
	{
		public string q { get; set; }
		public string a { get; set; } 

	}

}

